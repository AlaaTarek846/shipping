<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StorageSystemCompany extends Model
{
    use HasFactory;

    //    =======================Models Storage System Company fields

    protected $guarded = ['id'];


}
