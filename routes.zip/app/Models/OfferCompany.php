<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OfferCompany extends Model
{
    use HasFactory;

    //    =======================Models Offer Company fields

    protected $guarded = ['id'];
}
